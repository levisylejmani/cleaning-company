import React from 'react';
import { Shield, Award, Clock, Heart } from 'lucide-react';

const About = () => {
  const values = [
    {
      icon: Shield,
      title: 'Trusted & Reliable',
      description: 'Fully insured and bonded with background-checked cleaning professionals.'
    },
    {
      icon: Award,
      title: 'Quality Guaranteed',
      description: '100% satisfaction guarantee with consistent, high-quality cleaning standards.'
    },
    {
      icon: Clock,
      title: 'Flexible Scheduling',
      description: 'Same-day service available with scheduling that works around your life.'
    },
    {
      icon: Heart,
      title: 'Family-Owned',
      description: 'Local Orlando business committed to serving our community with care.'
    }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-br from-[#f5f1e7] to-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div>
            <h2 className="text-4xl font-bold text-[#7a2329] mb-6">
              Why Choose Elite Clean?
            </h2>
            
            <p className="text-xl text-gray-700 mb-8 leading-relaxed">
              For over 5 years, we've been Orlando's trusted cleaning service, 
              providing exceptional residential and commercial cleaning solutions. 
              Our team is dedicated to delivering spotless results while giving 
              you back the time to focus on what matters most.
            </p>

            <div className="space-y-6">
              {values.map((value, index) => {
                const IconComponent = value.icon;
                return (
                  <div key={index} className="flex gap-4">
                    <div className="bg-[#7a2329] w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0">
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-[#7a2329] mb-2">
                        {value.title}
                      </h3>
                      <p className="text-gray-600 leading-relaxed">
                        {value.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-10">
              <button className="bg-[#7a2329] text-white px-8 py-4 rounded-full font-semibold hover:bg-[#5a1a1f] transition-colors text-lg">
                Schedule Your Cleaning
              </button>
            </div>
          </div>

          {/* Right Content */}
          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <img
                  src="https://images.pexels.com/photos/6195942/pexels-photo-6195942.jpeg?auto=compress&cs=tinysrgb&w=400"
                  alt="Professional cleaning team"
                  className="w-full h-48 object-cover rounded-2xl shadow-lg"
                />
                <img
                  src="https://images.pexels.com/photos/6197119/pexels-photo-6197119.jpeg?auto=compress&cs=tinysrgb&w=400"
                  alt="Cleaning supplies"
                  className="w-full h-64 object-cover rounded-2xl shadow-lg"
                />
              </div>
              <div className="space-y-4 pt-8">
                <img
                  src="https://images.pexels.com/photos/6195123/pexels-photo-6195123.jpeg?auto=compress&cs=tinysrgb&w=400"
                  alt="Clean modern kitchen"
                  className="w-full h-64 object-cover rounded-2xl shadow-lg"
                />
                <img
                  src="https://images.pexels.com/photos/6197434/pexels-photo-6197434.jpeg?auto=compress&cs=tinysrgb&w=400"
                  alt="Spotless bathroom"
                  className="w-full h-48 object-cover rounded-2xl shadow-lg"
                />
              </div>
            </div>

            {/* Stats Overlay */}
            <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 bg-white rounded-2xl shadow-xl p-6 border border-gray-100">
              <div className="grid grid-cols-3 gap-6 text-center">
                <div>
                  <div className="text-2xl font-bold text-[#7a2329]">1000+</div>
                  <div className="text-sm text-gray-600">Homes Cleaned</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-[#7a2329]">5 Stars</div>
                  <div className="text-sm text-gray-600">Average Rating</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-[#7a2329]">24/7</div>
                  <div className="text-sm text-gray-600">Support</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;