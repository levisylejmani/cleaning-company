import React from 'react';
import { Home, Sparkles, Truck, Building, Wrench, Users } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Home,
      title: 'Residential Cleaning',
      description: 'Regular house cleaning services tailored to your schedule and preferences.',
      features: ['Weekly/Bi-weekly/Monthly', 'Custom Cleaning Plans', 'Eco-Friendly Products'],
      price: 'Starting at $120'
    },
    {
      icon: Sparkles,
      title: 'Deep Cleaning',
      description: 'Comprehensive deep cleaning service for a thorough, top-to-bottom clean.',
      features: ['All Rooms & Surfaces', 'Inside Appliances', 'Detailed Sanitization'],
      price: 'Starting at $200'
    },
    {
      icon: Truck,
      title: 'Move-in/Move-out',
      description: 'Complete cleaning service for your move, ensuring your space is spotless.',
      features: ['Full Property Clean', 'Inside Cabinets', 'Window Cleaning'],
      price: 'Starting at $250'
    },
    {
      icon: Building,
      title: 'Office Cleaning',
      description: 'Professional commercial cleaning services for offices and businesses.',
      features: ['Daily/Weekly Service', 'Restroom Maintenance', 'Floor Care'],
      price: 'Custom Quote'
    },
    {
      icon: Wrench,
      title: 'Post-Construction',
      description: 'Specialized cleaning after construction or renovation projects.',
      features: ['Dust & Debris Removal', 'Window & Surface Cleaning', 'Final Inspection'],
      price: 'Custom Quote'
    },
    {
      icon: Users,
      title: 'Commercial Services',
      description: 'Comprehensive cleaning solutions for retail, medical, and industrial spaces.',
      features: ['Flexible Scheduling', 'Industry Standards', 'Equipment Provided'],
      price: 'Custom Quote'
    }
  ];

  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-[#7a2329] mb-4">
            Our Cleaning Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From regular house cleaning to specialized commercial services, 
            we offer comprehensive solutions to keep your space pristine.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div
                key={index}
                className="group bg-[#f5f1e7] rounded-2xl p-8 hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border border-gray-100"
              >
                <div className="bg-[#7a2329] w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <IconComponent className="w-8 h-8 text-white" />
                </div>

                <h3 className="text-2xl font-bold text-[#7a2329] mb-4">
                  {service.title}
                </h3>

                <p className="text-gray-700 mb-6 leading-relaxed">
                  {service.description}
                </p>

                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center gap-2 text-gray-600">
                      <div className="w-2 h-2 bg-[#7a2329] rounded-full"></div>
                      {feature}
                    </li>
                  ))}
                </ul>

                <div className="flex items-center justify-between">
                  <span className="text-xl font-bold text-[#7a2329]">
                    {service.price}
                  </span>
                  <button className="bg-[#7a2329] text-white px-6 py-2 rounded-full hover:bg-[#5a1a1f] transition-colors">
                    Learn More
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="text-center mt-16">
          <div className="bg-[#7a2329] text-white rounded-2xl p-8 max-w-4xl mx-auto">
            <h3 className="text-3xl font-bold mb-4">Need a Custom Quote?</h3>
            <p className="text-xl mb-6 opacity-90">
              Every space is unique. Let us create a personalized cleaning plan that fits your needs and budget.
            </p>
            <button className="bg-[#f5f1e7] text-[#7a2329] px-8 py-3 rounded-full font-semibold hover:bg-white transition-colors text-lg">
              Get Free Estimate
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;